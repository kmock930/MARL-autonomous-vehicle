# VMAS vs MPE

## Installing MPE
```
git submodule update --init --recursive
```
Then `cd` to `mpe_comparison/mpe` and
```
pip install -e .
```
## Running the comparison
```
python mpe_performance_comparison.py
```
